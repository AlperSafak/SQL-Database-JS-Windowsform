﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;

namespace SQL_SERVER_Database
{
    public enum HarfNotları {aa,ba,bb,cb,cc,dc,dd,fd,ff }
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        ArrayList Stu_Ad = new ArrayList();
        ArrayList Stu_Soyad = new ArrayList();
        ArrayList Ders_Ad = new ArrayList();

        private void Kayıt_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-MDQSHF0;Initial Catalog=Personel;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("insert into ÖğrenciBilgi(ÖğrenciNo,ÖğrenciAd,ÖğrenciSoyad) values (@ÖğrenciNo, @ÖğrenciAd, @ÖğrenciSoyad)", con);

            cmd.Parameters.AddWithValue("@ÖğrenciNo", OgNo.Text);
            cmd.Parameters.AddWithValue("@ÖğrenciAd", Og_ad.Text);
            cmd.Parameters.AddWithValue("@ÖğrenciSoyad", Og_Soyad.Text);
            con.Open();
            int i = cmd.ExecuteNonQuery();

            if (i != 0)
            {
                MessageBox.Show("Data Saved");
            }
            else
            {
                MessageBox.Show("data not saved");

            }
            SqlCommand cmd2 = new SqlCommand("insert into SınavSonuç(ÖğrenciNo,ÖğrenciAdSoyad) values(@ÖğrenciNo,ÖğrenciAdSoyad)", con);
            cmd2.Parameters.AddWithValue("@ÖğrenciNo", OgNo.Text);
            //    cmd2.Parameters.AddWithValue("@ÖğrenciAdSoyad", Og_ad.Text+" "+Og_Soyad);
            cmd2.ExecuteNonQuery();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            string connection = "Data Source=DESKTOP-MDQSHF0;Initial Catalog=Personel;Integrated Security=True";
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string command = "Select ÖğrenciNo,ÖğrenciAd,ÖğrenciSoyad from ÖğrenciBilgi";
            string command2 = "Select DersKodu,DersAdı from Dersler";
            SqlCommand cmd = new SqlCommand(command, con);
            SqlCommand cmd2 = new SqlCommand(command2, con);
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                Og_Id.Items.Add(String.Format(dr.GetValue(0).ToString()));


                Stu_Ad.Add(dr.GetValue(1).ToString());
                Stu_Soyad.Add(dr.GetValue(2).ToString());


            }
            dr.Close();
            SqlDataReader dr2 = cmd2.ExecuteReader();
            while (dr2.Read())
            {
                DersKod.Items.Add(String.Format(dr2.GetValue(0).ToString()));
                Ders_Ad.Add(dr2.GetValue(1).ToString());
            }



            con.Close();

        }

        private void Not_Ekle_Click(object sender, EventArgs e)
        {
            //SqlCommand cmd = new SqlCommand("insert into ÖğrenciBilgi(ÖğrenciNo,ÖğrenciAd,ÖğrenciSoyad) values (@ÖğrenciNo, @ÖğrenciAd, @ÖğrenciSoyad)", con);
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-MDQSHF0;Initial Catalog=Personel;Integrated Security=True");
            string İşlemler = İşlem.SelectedItem.ToString();
           
            con.Open();
            string command2 = "Select DersKodu,ÖğrenciAdSoyad from SınavSonuç";
            SqlCommand cmd2 = new SqlCommand(command2, con);
            SqlDataReader dr2 = cmd2.ExecuteReader();
            bool insert = true;
            while (dr2.Read())
            {                 
                if (Equals(DersKod.SelectedItem.ToString(),dr2.GetValue(0).ToString()) )
                {
                    if (Equals(Og_Ad_Soyad_.Text,dr2.GetValue(1).ToString()))
                    {


                        dr2.Close();
                        insert = false;
                        string command = "update SınavSonuç set Liste=@Liste,ÖğrenciAdSoyad=@ÖğrenciAdSoyad," + İşlemler + "=@" + İşlemler + " where ÖğrenciNo=@ÖğrenciNo and DersKodu=@derskodu";
                        SqlCommand cmd = new SqlCommand(command, con);
                        cmd.Parameters.AddWithValue("@ÖğrenciAdSoyad", Og_Ad_Soyad_.Text);
                        cmd.Parameters.AddWithValue("@derskodu", DersKod.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@ÖğrenciNo", Og_Id.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@Liste", Og_Id.SelectedItem.ToString() + "/" + DersKod.SelectedItem.ToString());
                        string parameter = "@" + İşlem.SelectedItem.ToString();
                        cmd.Parameters.AddWithValue(parameter, SınavNot.Text);
                        int i = cmd.ExecuteNonQuery();
                        if (i != 0)
                        {
                            MessageBox.Show("data saved");

                        }
                        else
                        {
                            MessageBox.Show("data not saved");
                        }
                        break;
                    }

                }

            }
            dr2.Close();
            if (insert)
                    {


                        // insert into komutu eklencek , Liste primary key için otomatik değer atanacak

                        
                        string InsertCommand = "insert into SınavSonuç(Liste,ÖğrenciNo,ÖğrenciAdSoyad,DersKodu," + İşlemler + ") values (@Liste,@ÖğrenciNo,@öğrenciAdSoyad,@DersKodu,@" + İşlemler + ")";
                        SqlCommand InsertCmd = new SqlCommand(InsertCommand, con);
                        InsertCmd.Parameters.AddWithValue("@Liste", DersKod.SelectedItem.ToString()+"/" + Og_Id.SelectedItem.ToString());
                        InsertCmd.Parameters.AddWithValue("@ÖğrenciAdSoyad", Og_Ad_Soyad_.Text);
                        InsertCmd.Parameters.AddWithValue("@derskodu", DersKod.SelectedItem.ToString());
                        InsertCmd.Parameters.AddWithValue("@ÖğrenciNo", Og_Id.SelectedItem.ToString());
                        string parameter = "@" + İşlem.SelectedItem.ToString();
                        InsertCmd.Parameters.AddWithValue(parameter, SınavNot.Text);
                        int a = InsertCmd.ExecuteNonQuery();
                        if (a != 0)
                        {
                            MessageBox.Show("data saved");

                        }
                        else
                        {
                            MessageBox.Show("data not saved");
                        }
                    }
                con.Close();
        }

        private void Og_Id_SelectedIndexChanged(object sender, EventArgs e)
        {


           

            for (int i = 0; i < Og_Id.Items.Count; i++)
            {
                if (Og_Id.SelectedIndex == i)
                {

                    Og_Ad_Soyad_.Text = Stu_Ad[i].ToString() + " " + Stu_Soyad[i].ToString();

                }

            }
        }

        private void İşlem_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Ders_Ort_Click(object sender, EventArgs e)
        {
            string connection = "Data Source=DESKTOP-MDQSHF0;Initial Catalog=Personel;Integrated Security=True";
            SqlConnection con = new SqlConnection(connection);
            con.Open();
            string command = "Select Vize1,Vize2,Final from SınavSonuç where ÖğrenciNo=@ÖğrenciNo and DersKodu=@DersKodu";
            SqlCommand cmd = new SqlCommand(command, con);
            cmd.Parameters.AddWithValue("@ÖğrenciNo", Og_Id.SelectedItem.ToString());
            cmd.Parameters.AddWithValue("@DersKodu", DersKod.SelectedItem.ToString());

            SqlDataReader dr3 = cmd.ExecuteReader();
            while (dr3.Read())
            {
                double ort = (double)dr3.GetInt32(0) * 0.3 + (double)dr3.GetInt32(1) * 0.3 + (double)dr3.GetInt32(2) * 0.4;
                DersOrt.Text = ort.ToString();
               
            }
            dr3.Close();
           

            double[,] TumOrt = new double[DersKod.Items.Count, Og_Id.Items.Count];
            TumOrt[DersKod.SelectedIndex, Og_Id.SelectedIndex] = double.Parse(DersOrt.Text);

            double[,] HarfNotu = new double[DersKod.Items.Count, Og_Id.Items.Count];
          

            for (int k = 9; k >= 1; k--)
            {
                if (TumOrt[DersKod.SelectedIndex, Og_Id.SelectedIndex] >= k * 10)
                {
                    HarfNotu[DersKod.SelectedIndex, Og_Id.SelectedIndex] = (k - 1) * (0.5);
                    HarfNotları harf = (HarfNotları)(9-k);

                    HarfNot.Text = harf.ToString();
                    break;
                }
            }
            string command2 = "update SınavSonuç set ÖğrenciOrtalama=@ÖğrenciOrtalama,ÖğrenciHarfNotu=@ÖğrenciHarfNotu where ÖğrenciNo=@ÖğrenciNo and DersKodu=@DersKodu";
            SqlCommand cmd2 = new SqlCommand(command2, con);
            cmd2.Parameters.AddWithValue("DersKodu", DersKod.SelectedItem.ToString());
            cmd2.Parameters.AddWithValue("@ÖğrenciNo", Og_Id.SelectedItem.ToString());
            cmd2.Parameters.AddWithValue("@ÖğrenciOrtalama", DersOrt.Text);
            cmd2.Parameters.AddWithValue("@ÖğrenciHarfNotu", HarfNot.Text.ToUpper()); 
            cmd2.ExecuteNonQuery();
      














            /* aa  90 4
                  * ba 80    3.5
                  * bb 70    3
                  * cb 60    2.5
                  * cc50     2
                  * dc 40    1.5
                  * dd  30    1
                  * fd 20    0.5
                  * ff 0-20  0 



                }



          */
        }

        private void DersKod_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < DersKod.Items.Count; i++)
            {
                if (DersKod.SelectedIndex == i)
                {

                    Ders_Adı.Text = Ders_Ad[i].ToString();

                }
            }
        }

       

    }
   
}

