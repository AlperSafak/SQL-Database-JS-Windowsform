﻿
namespace SQL_SERVER_Database
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Not_Ekle = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Og_Id = new System.Windows.Forms.ComboBox();
            this.İşlem = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Ders_Ort = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SınavNot = new System.Windows.Forms.TextBox();
            this.DersOrt = new System.Windows.Forms.TextBox();
            this.Kayıt = new System.Windows.Forms.Button();
            this.OgNo = new System.Windows.Forms.TextBox();
            this.Og_ad = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Og_Soyad = new System.Windows.Forms.TextBox();
            this.Og_Ad_Soyad_ = new System.Windows.Forms.TextBox();
            this.DersKod = new System.Windows.Forms.ComboBox();
            this.Ders_Adı = new System.Windows.Forms.TextBox();
            this.HarfNot = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Not_Ekle
            // 
            this.Not_Ekle.Location = new System.Drawing.Point(132, 308);
            this.Not_Ekle.Name = "Not_Ekle";
            this.Not_Ekle.Size = new System.Drawing.Size(127, 36);
            this.Not_Ekle.TabIndex = 0;
            this.Not_Ekle.Text = "Not Ekle";
            this.Not_Ekle.UseVisualStyleBackColor = true;
            this.Not_Ekle.Click += new System.EventHandler(this.Not_Ekle_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 274);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Ders İşlemleri";
            // 
            // Og_Id
            // 
            this.Og_Id.FormattingEnabled = true;
            this.Og_Id.Location = new System.Drawing.Point(138, 197);
            this.Og_Id.Name = "Og_Id";
            this.Og_Id.Size = new System.Drawing.Size(121, 24);
            this.Og_Id.TabIndex = 5;
            this.Og_Id.SelectedIndexChanged += new System.EventHandler(this.Og_Id_SelectedIndexChanged);
            // 
            // İşlem
            // 
            this.İşlem.FormattingEnabled = true;
            this.İşlem.Items.AddRange(new object[] {
            "Vize1",
            "Vize2",
            "Final",
            "diğer"});
            this.İşlem.Location = new System.Drawing.Point(138, 267);
            this.İşlem.Name = "İşlem";
            this.İşlem.Size = new System.Drawing.Size(121, 24);
            this.İşlem.TabIndex = 7;
            this.İşlem.SelectedIndexChanged += new System.EventHandler(this.İşlem_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 200);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "Öğrenciler";
            // 
            // Ders_Ort
            // 
            this.Ders_Ort.Location = new System.Drawing.Point(12, 383);
            this.Ders_Ort.Name = "Ders_Ort";
            this.Ders_Ort.Size = new System.Drawing.Size(127, 55);
            this.Ders_Ort.TabIndex = 9;
            this.Ders_Ort.Text = "Öğrencinin Ders Ortalaması";
            this.Ders_Ort.UseVisualStyleBackColor = true;
            this.Ders_Ort.Click += new System.EventHandler(this.Ders_Ort_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 238);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 17);
            this.label2.TabIndex = 10;
            this.label2.Text = "Ders Kodu";
            // 
            // SınavNot
            // 
            this.SınavNot.Location = new System.Drawing.Point(279, 267);
            this.SınavNot.Name = "SınavNot";
            this.SınavNot.Size = new System.Drawing.Size(125, 22);
            this.SınavNot.TabIndex = 11;
            // 
            // DersOrt
            // 
            this.DersOrt.Location = new System.Drawing.Point(145, 390);
            this.DersOrt.Name = "DersOrt";
            this.DersOrt.Size = new System.Drawing.Size(121, 22);
            this.DersOrt.TabIndex = 14;
            // 
            // Kayıt
            // 
            this.Kayıt.Location = new System.Drawing.Point(29, 37);
            this.Kayıt.Name = "Kayıt";
            this.Kayıt.Size = new System.Drawing.Size(141, 49);
            this.Kayıt.TabIndex = 17;
            this.Kayıt.Text = "YeniÖğrenciKaydı";
            this.Kayıt.UseVisualStyleBackColor = true;
            this.Kayıt.Click += new System.EventHandler(this.Kayıt_Click);
            // 
            // OgNo
            // 
            this.OgNo.Location = new System.Drawing.Point(186, 50);
            this.OgNo.Name = "OgNo";
            this.OgNo.Size = new System.Drawing.Size(121, 22);
            this.OgNo.TabIndex = 18;
            // 
            // Og_ad
            // 
            this.Og_ad.Location = new System.Drawing.Point(313, 50);
            this.Og_ad.Name = "Og_ad";
            this.Og_ad.Size = new System.Drawing.Size(121, 22);
            this.Og_ad.TabIndex = 19;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(207, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 17);
            this.label5.TabIndex = 20;
            this.label5.Text = "ÖğrenciNo";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(321, 21);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 17);
            this.label6.TabIndex = 21;
            this.label6.Text = "Öğrenci Ad";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(448, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 17);
            this.label7.TabIndex = 22;
            this.label7.Text = "Öğrenci Soyad";
            // 
            // Og_Soyad
            // 
            this.Og_Soyad.Location = new System.Drawing.Point(440, 50);
            this.Og_Soyad.Name = "Og_Soyad";
            this.Og_Soyad.Size = new System.Drawing.Size(121, 22);
            this.Og_Soyad.TabIndex = 23;
            // 
            // Og_Ad_Soyad_
            // 
            this.Og_Ad_Soyad_.Location = new System.Drawing.Point(279, 197);
            this.Og_Ad_Soyad_.Name = "Og_Ad_Soyad_";
            this.Og_Ad_Soyad_.Size = new System.Drawing.Size(125, 22);
            this.Og_Ad_Soyad_.TabIndex = 25;
            // 
            // DersKod
            // 
            this.DersKod.FormattingEnabled = true;
            this.DersKod.Location = new System.Drawing.Point(138, 235);
            this.DersKod.Name = "DersKod";
            this.DersKod.Size = new System.Drawing.Size(121, 24);
            this.DersKod.TabIndex = 27;
            this.DersKod.SelectedIndexChanged += new System.EventHandler(this.DersKod_SelectedIndexChanged);
            // 
            // Ders_Adı
            // 
            this.Ders_Adı.Location = new System.Drawing.Point(279, 235);
            this.Ders_Adı.Name = "Ders_Adı";
            this.Ders_Adı.Size = new System.Drawing.Size(125, 22);
            this.Ders_Adı.TabIndex = 28;
            // 
            // HarfNot
            // 
            this.HarfNot.Location = new System.Drawing.Point(279, 390);
            this.HarfNot.Name = "HarfNot";
            this.HarfNot.Size = new System.Drawing.Size(121, 22);
            this.HarfNot.TabIndex = 29;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(293, 358);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 17);
            this.label4.TabIndex = 30;
            this.label4.Text = "Harf Notu";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.HarfNot);
            this.Controls.Add(this.Ders_Adı);
            this.Controls.Add(this.DersKod);
            this.Controls.Add(this.Og_Ad_Soyad_);
            this.Controls.Add(this.Og_Soyad);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Og_ad);
            this.Controls.Add(this.OgNo);
            this.Controls.Add(this.Kayıt);
            this.Controls.Add(this.DersOrt);
            this.Controls.Add(this.SınavNot);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Ders_Ort);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.İşlem);
            this.Controls.Add(this.Og_Id);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Not_Ekle);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Not_Ekle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox Og_Id;
        private System.Windows.Forms.ComboBox İşlem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Ders_Ort;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox SınavNot;
        private System.Windows.Forms.TextBox DersOrt;
        private System.Windows.Forms.Button Kayıt;
        private System.Windows.Forms.TextBox OgNo;
        private System.Windows.Forms.TextBox Og_ad;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Og_Soyad;
        private System.Windows.Forms.TextBox Og_Ad_Soyad_;
        private System.Windows.Forms.ComboBox DersKod;
        private System.Windows.Forms.TextBox Ders_Adı;
        private System.Windows.Forms.TextBox HarfNot;
        private System.Windows.Forms.Label label4;
    }
}

